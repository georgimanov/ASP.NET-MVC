﻿namespace MvcTemplate.Common
{
    public class GlobalConstants
    {
        public const string AdministratorRoleName = "Administrator";
    }
}
