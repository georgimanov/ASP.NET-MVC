﻿namespace Crawler
{
    using System;
    using AngleSharp;
    using MvcTemplate.Data;
    using MvcTemplate.Data.Common;
    using MvcTemplate.Data.Models;
    using MvcTemplate.Services.Data;

    public static class Program
    {
        public static void Main()
        {
        }
    }
}
