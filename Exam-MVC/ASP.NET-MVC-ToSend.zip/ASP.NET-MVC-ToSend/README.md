# ASP.NET-MVC-Template
ASP.NET-MVC-Template

## Build status

[![Build status](https://ci.appveyor.com/api/projects/status/8dskbn908e27vevx?svg=true)](https://ci.appveyor.com/project/NikolayIT/asp-net-mvc-template)

## Video

Video with template creating (in Bulgarian) can be seen on YouTube: [https://www.youtube.com/watch?v=xhoBt9MscrY](https://www.youtube.com/watch?v=xhoBt9MscrY)
